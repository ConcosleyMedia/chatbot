n8n recommends using an SVG for your node icon, but you can also use PNG. If using PNG, the icon resolution should be 60x60px. Node icons should have a square or near-square aspect ratio.

/// note | Don't reference Font Awesome
If you want to use a Font Awesome icon in your node, download and embed the image.
///