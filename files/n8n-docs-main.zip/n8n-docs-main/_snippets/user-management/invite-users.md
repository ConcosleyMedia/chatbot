You can now invite other people to your n8n instance.

1. Sign into your workspace with your owner account. (If you are in the Admin Panel open your **Workspace** from the Dashboard)
2. Click the three dots next to your user icon at the bottom left and click **Settings**. n8n opens your **Personal settings** page.
3. Click **Users** to go to the **Users** page.
4. Click **Invite**.
5. Enter the new user's email address.
6. Click **Invite user**. n8n sends an email with a link for the new user to join.
