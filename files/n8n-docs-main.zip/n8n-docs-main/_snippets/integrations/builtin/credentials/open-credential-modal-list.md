1. In n8n, open the **Admin Panel** (left menu)
1. Select **Credentials** > **New**.
