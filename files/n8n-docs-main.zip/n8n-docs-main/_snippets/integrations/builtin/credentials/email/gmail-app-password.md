To generate an app password:

1. In your Google account, go to [App passwords](https://myaccount.google.com/apppasswords){:target=_blank .external-link}.
2. Enter an **App name** for your new app password, like `n8n credential`.
3. Select **Create**.
4. Copy the generated app password. You'll use this in your n8n credential.

Refer to Google's [Sign in with app passwords documentation](https://support.google.com/accounts/answer/185833?hl=en){:target=_blank .external-link} for more information.