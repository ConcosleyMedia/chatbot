/// note | Note for n8n Cloud users
For the following nodes, you can authenticate by selecting **Sign in with Google** in the OAuth section: 

* [Google Calendar](/integrations/builtin/app-nodes/n8n-nodes-base.googlecalendar/index.md)
* [Google Contacts](/integrations/builtin/app-nodes/n8n-nodes-base.googlecontacts.md)
* [Google Drive](/integrations/builtin/app-nodes/n8n-nodes-base.googledrive/index.md)
* [Google Mail](/integrations/builtin/app-nodes/n8n-nodes-base.gmail/index.md)
* [Google Sheets](/integrations/builtin/app-nodes/n8n-nodes-base.googlesheets/index.md)
* [Google Sheets Trigger](/integrations/builtin/trigger-nodes/n8n-nodes-base.googlesheetstrigger/index.md)
* [Google Tasks](/integrations/builtin/app-nodes/n8n-nodes-base.googletasks.md)
///
