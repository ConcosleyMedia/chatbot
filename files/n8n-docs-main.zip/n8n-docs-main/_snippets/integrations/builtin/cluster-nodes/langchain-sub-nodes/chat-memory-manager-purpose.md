This node is useful when you:

* Can't add a memory node directly.
* Need to do more complex memory management, beyond what the memory nodes offer. For example, you can add this node to check the memory size of the Agent node's response, and reduce it if needed.
* Want to inject messages to the AI that look like user messages, to give the AI more context.
