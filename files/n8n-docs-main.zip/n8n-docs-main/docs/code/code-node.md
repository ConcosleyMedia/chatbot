---
#https://www.notion.so/n8n/Frontmatter-432c2b8dff1f43d4b1c8d20075510fe4
contentType: [integration, reference]
tags:
  - code node
  - code
hide:
  - tags
---

# Using the Code node

--8<-- "_snippets/integrations/builtin/core-nodes/code-node.md"
