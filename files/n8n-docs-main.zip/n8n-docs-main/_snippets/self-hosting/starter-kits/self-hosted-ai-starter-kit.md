## Self-hosted AI Starter Kit

New to working with AI and using self-hosted n8n? Try n8n's [self-hosted AI Starter Kit](/hosting/starter-kits/ai-starter-kit.md) to get started with a proof-of-concept or demo playground using Ollama, Qdrant, and PostgreSQL.
