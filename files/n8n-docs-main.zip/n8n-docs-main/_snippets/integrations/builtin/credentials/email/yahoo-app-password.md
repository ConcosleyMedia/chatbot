1. Log in to your Yahoo account [Security page](https://login.yahoo.com/account/security).
2. Select **Generate app password** or **Generate and manage app passwords**.
3. Select **Get Started**.
2. Enter an **App name** for your new app password, like `n8n credential`.
3. Select **Generate password**.
4. Copy the generated app password. You'll use this in your n8n credential.

Refer to Yahoo's [Generate and manage 3rd-party app passwords](https://help.yahoo.com/kb/generate-manage-third-party-passwords-sln15241.html){:target=_blank .external-link} for more information.