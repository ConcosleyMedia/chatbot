* Learn more about [configuring](/hosting/configuration/environment-variables/index.md) and [scaling](/hosting/scaling/overview.md) n8n.
* Or explore using n8n: try the [Quickstarts](/try-it-out/index.md).
