When you open n8n, you'll see either:

* An empty workflow: if you have no workflows and you're logging in for the first time. Use this workflow.
* The **Workflows** list on the **Overview** page. Select the <span class="inline-image">![universal create resource icon](/_images/common-icons/universal-resource-button.png){.off-glb}</span> **button** to create a new workflow.
