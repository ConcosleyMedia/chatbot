In your environment variables, set `N8N_TEMPLATES_ENABLED` to false.
