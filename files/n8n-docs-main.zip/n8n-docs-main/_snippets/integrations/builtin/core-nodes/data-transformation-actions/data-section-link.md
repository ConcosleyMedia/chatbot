Learn more about [data structure and data flow](/data/index.md) in n8n workflows.
