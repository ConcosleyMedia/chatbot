/// info | Feature availability
* Available on Enterprise.
* You need to be an n8n instance owner, admin, or project owner to set up source control, and to send work to and from Git.
///
