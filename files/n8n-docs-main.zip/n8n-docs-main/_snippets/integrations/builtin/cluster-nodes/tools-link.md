Refer to [LangChain's documentation on tools](https://langchain-ai.github.io/langgraphjs/how-tos/tool-calling/){:target=_blank .external-link} for more information about tools in LangChain.
