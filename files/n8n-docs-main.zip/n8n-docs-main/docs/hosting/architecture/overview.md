---
#https://www.notion.so/n8n/Frontmatter-432c2b8dff1f43d4b1c8d20075510fe4
description: Understand n8n's architecture
contentType: overview
---

# Architecture

Understanding n8n's underlying architecture is helpful if you need to:

* Embed n8n
* Customize n8n's default databases

This section is a work in progress. If you have questions, please try the [forum](https://community.n8n.io/){:target=_blank .external-link} and let n8n know which architecture documents would be useful for you.
