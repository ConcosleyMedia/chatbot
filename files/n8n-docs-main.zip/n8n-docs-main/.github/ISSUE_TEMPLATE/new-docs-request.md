---
name: New docs request
about: Suggest additional pages or information to improve docs
title: "[DOCS-REQUEST] - "
labels: enhancement
assignees: ''

---

Thanks for helping us improve docs! Please give us as much information as you can about the changes you'd like to see.

**What information is missing?**


**Describe the page/pages you'd like**


**Additional context**
Add any other context or screenshots about the feature request here.
