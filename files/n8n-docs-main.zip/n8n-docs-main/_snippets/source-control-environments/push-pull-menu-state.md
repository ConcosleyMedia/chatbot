??? Details "View screenshot" 
	<figure markdown>
		![Pull and push buttons when menu is closed](/_images/source-control-environments/pull-push-menu-closed.png)
		<figcaption>Pull and push buttons when menu is closed</figcaption>
	</figure>

	<figure markdown>
		![Pull and push buttons when menu is open](/_images/source-control-environments/pull-push-menu-open.png)
		<figcaption>Pull and push buttons when menu is open</figcaption>
	</figure>
