The advantages of this pattern are:

* An added safety layer to prevent changes getting into your production environment by mistake. You have to do a pull request in GitHub to copy work between environments.
* It supports more than two instances.

The disadvantage is more manual steps to copy work between environments.

