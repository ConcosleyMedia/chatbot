/// info | Feature availability
Embed requires an embed license. For more information about when to use Embed, as well as costs and licensing processes, refer to [Embed](https://n8n.io/embed/){:target=_blank .external-link} on the n8n website.
///