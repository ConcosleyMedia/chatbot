---
#https://www.notion.so/n8n/Frontmatter-432c2b8dff1f43d4b1c8d20075510fe4
title: Set up SAML SSO
description: "Set up SAML Single Sign-On for your self-hosted n8n instance."
contentType: howto
---

# Set up SAML Single Sign-On (SSO)

--8<-- "_snippets/user-management/saml-overview.md"
