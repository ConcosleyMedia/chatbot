## Using basic auth

Use this generic authentication if your app or service supports basic authentication.

To configure this credential, enter:

- The **Username** you use to access the app or service your HTTP Request is targeting
- The **Password** that goes with that username
