---
#https://www.notion.so/n8n/Frontmatter-432c2b8dff1f43d4b1c8d20075510fe4
title: Data flow within nodes
description: How nodes process data items.
contentType: explanation
---

# Data flow within nodes

--8<-- "_snippets/flow-logic/data-flow-nodes.md"
