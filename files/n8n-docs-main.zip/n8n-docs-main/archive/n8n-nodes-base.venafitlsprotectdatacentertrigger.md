# Venafi TLS Protect Datacenter Trigger

[Venafi](https://www.venafi.com/){:target=_blank .external-link} is a cybersecurity company providing services for machine identity management. They offer solutions to manage and protect identities for a wide range of machine types, delivering global visibility, lifecycle automation, and actionable intelligence.

///  note  | Credentials
You can find authentication information for this node [here](/integrations/builtin/credentials/venafitlsprotectdatacenter/).
///