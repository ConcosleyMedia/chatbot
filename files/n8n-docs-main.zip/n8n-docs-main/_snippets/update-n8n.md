## How to update n8n

The steps to update your n8n depend on which n8n platform you use. Refer to the documentation for your n8n:

* [Cloud](/manage-cloud/update-cloud-version.md)
* Self-hosted options:
    * [npm](/hosting/installation/npm.md)
    * [Docker](/hosting/installation/docker.md)
