Enter the number of times the model should run to try and generate a good answer from the user's prompt.

Defaults to `10`.
