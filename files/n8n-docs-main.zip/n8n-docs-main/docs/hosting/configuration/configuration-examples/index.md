---
#https://www.notion.so/n8n/Frontmatter-432c2b8dff1f43d4b1c8d20075510fe4
title: Configuration examples
description: An overview containing different configuration examples.
contentType: overview
---

# Configuration examples

This section contains examples for how to configure n8n to solve particular use cases.

[[% import "_macros/section-toc.html" as sectionToc %]]

[[ sectionToc.sectionToc(page) ]]
