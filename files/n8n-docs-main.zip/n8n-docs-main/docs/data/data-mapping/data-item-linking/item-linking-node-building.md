---
#https://www.notion.so/n8n/Frontmatter-432c2b8dff1f43d4b1c8d20075510fe4
contentType: howto
---

# Item linking for node creators

--8<-- "_snippets/data/data-mapping/item-linking-node-creators.md"
