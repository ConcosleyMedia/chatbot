/// info | Feature availability
Custom executions data is available on:

* Cloud: Pro, Enterprise
* Self-Hosted: Enterprise, registered Community

Available in version 0.222.0 and above.
///
