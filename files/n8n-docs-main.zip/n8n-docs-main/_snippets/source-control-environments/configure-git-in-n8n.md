1. Go to **Settings** > **Environments**.
1. In **Git repository URL** enter the SSH URL for your repository.
1. n8n supports ED25519 and RSA public key algorithms. ED25519 is the default. Select **RSA** under **SSH Key** if your git host requires RSA.
1. Copy the SSH key.
