/// note | Note for n8n Cloud users
Cloud users don't need to provide connection details. Select **Connect my account** to connect through your browser.
///