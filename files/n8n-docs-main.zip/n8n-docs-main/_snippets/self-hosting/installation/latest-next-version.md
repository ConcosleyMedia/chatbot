/// note | Latest and Next versions
n8n releases a new minor version most weeks. The `latest` version is for production use. `next` is the most recent release. You should treat `next` as a beta: it may be unstable. To report issues, use the [forum](https://community.n8n.io/c/questions/12){:target=_blank .external-link}.

Current `latest`: 1.94.1  
Current `next`: 1.95.1
///
